<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - Sweet Cake</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        table, th, td { border: 1px solid #ddd; }
        th, td { padding: 10px; text-align: left; }
        th { background-color: #f4f4f4; }
        .btn-hapus { background-color: #e74c3c; color: white; }
    </style>
</head>
<body>
<div class="navbar">
    <div class="container">
        <a href="index.php">Dashboard</a>
        <a href="produk.php">Kelola Produk</a>
        <a href="../auth/logout.php">Logout</a>
    </div>
</div>
