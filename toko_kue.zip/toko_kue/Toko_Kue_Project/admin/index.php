<?php
session_start();
require_once "../includes/auth.php";
require_once "../config/database.php";
$query_produk = mysqli_query($conn, "SELECT COUNT(*) as total FROM produk");
$total_produk = mysqli_fetch_assoc($query_produk)['total'];
include "../includes/header.php";
?>
<div class="container">
    <h1>Selamat Datang, <?= htmlspecialchars($_SESSION['admin_nama'] ?? 'Admin'); ?>!</h1>
    <div class="grid">
        <div class="card">
            <h3>Total Produk</h3>
            <h2><?= $total_produk; ?></h2>
            <p>Produk tersedia di etalase</p>
            <br>
            <a href="produk.php" class="btn">Kelola Produk</a>
        </div>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
