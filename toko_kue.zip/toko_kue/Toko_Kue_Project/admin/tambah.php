<?php
session_start();
require_once "../includes/auth.php";
include "../includes/header.php";
?>
<div class="container">
    <div class="card">
        <h1>Tambah Produk</h1>
        <?php include "../includes/flash.php"; ?>
        <form action="proses_produk.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="aksi" value="tambah">
            <label>Nama Produk</label>
            <input type="text" name="nama" required>
            <label>Kategori</label>
            <select name="kategori" required>
                <option value="">Pilih kategori</option>
                <option value="Cake">Cake</option>
                <option value="Brownies">Brownies</option>
                <option value="Donat">Donat</option>
            </select>
            <label>Deskripsi</label>
            <textarea name="deskripsi" rows="5" required></textarea>
            <label>Harga</label>
            <input type="number" name="harga" min="0" required>
            <label>Stok</label>
            <input type="number" name="stok" min="0" required>
            <label>Gambar Produk</label>
            <input type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp">
            <br><br>
            <button type="submit" class="btn">Simpan Produk</button>
            <a href="produk.php" class="btn">Kembali</a>
        </form>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
