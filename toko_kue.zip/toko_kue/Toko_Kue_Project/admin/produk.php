<?php
session_start();
require_once "../includes/auth.php";
require_once "../config/database.php";
$query = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");
include "../includes/header.php";
?>
<div class="container">
    <h1>Kelola Produk</h1>
    <?php include "../includes/flash.php"; ?>
    <a href="tambah.php" class="btn">Tambah Produk Baru</a>
    <div class="card" style="margin-top: 20px;">
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Gambar</th>
                    <th>Nama Produk</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($row = mysqli_fetch_assoc($query)): ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td>
                        <?php if ($row['gambar']): ?>
                            <img src="../uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" width="80" alt="Gambar">
                        <?php else: ?>
                            Tidak ada gambar
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($row['nama']); ?></td>
                    <td><?= htmlspecialchars($row['kategori']); ?></td>
                    <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                    <td><?= $row['stok']; ?></td>
                    <td>
                        <a href="edit.php?id=<?= $row['id']; ?>" class="btn">Edit</a>
                        <a href="hapus.php?id=<?= $row['id']; ?>" class="btn btn-hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?');">Hapus</a>
                    </td>
                </tr>
                <?php endwhile; ?>
                <?php if(mysqli_num_rows($query) == 0): ?>
                <tr><td colspan="7" style="text-align: center;">Belum ada data produk.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
